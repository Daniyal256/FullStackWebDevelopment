# ShopEase --- E-Commerce Website Design Specification

## 1. Project Overview

Build a modern, clean, responsive e-commerce website called **ShopEase**
using only:

-   HTML5
-   CSS3
-   Bootstrap 5
-   Bootstrap Icons may be used for interface icons

**Do not use JavaScript.**\
**Do not use React, Vue, Angular, jQuery, Tailwind, or any other
framework/library.**

The design should closely follow the approved ShopEase visual mockup: a
premium but friendly shopping interface with a dark navigation bar,
white/light-gray surfaces, orange calls-to-action, large product
imagery, rounded cards, subtle borders, and generous spacing.

The website should include these required areas/pages:

1.  Signup
2.  Login
3.  Navbar
4.  Hero Section
5.  Product Listing
6.  Product Details + Reviews
7.  Add Product to Cart UI
8.  Display Cart
9.  Edit Cart
10. Checkout
11. Order Success / Confirmation

> Because JavaScript is not allowed, cart buttons, quantity controls,
> filtering, sorting, authentication, checkout progression, and other
> interactive elements are **visual/static UI only** unless implemented
> through normal HTML links/forms and separate pages.

------------------------------------------------------------------------

# 2. Visual Direction

## Overall Style

The interface should feel:

-   Modern
-   Minimal
-   Premium
-   Friendly
-   Spacious
-   Product-focused
-   Easy to scan

Use Bootstrap's grid, spacing, forms, buttons, cards, badges, utilities,
and responsive classes wherever possible. Custom CSS should mainly
handle branding, fine spacing, image sizing, hover effects, and visual
polish.

Avoid clutter, excessive gradients, neon effects, glassmorphism, or
overly decorative elements.

------------------------------------------------------------------------

# 3. Design System

## Color Palette

Use a restrained palette.

  Purpose                   Suggested Color
  ------------------------- -------------------------
  Primary / CTA             `#ff5a1f`
  Primary Hover             `#e94b12`
  Dark Navbar / Headings    `#111827`
  Main Text                 `#1f2937`
  Secondary Text            `#6b7280`
  Page Background           `#ffffff`
  Soft Section Background   `#f8f9fa`
  Card Border               `#e5e7eb`
  Rating Stars              `#f59e0b`
  Success                   Bootstrap success green
  Danger / Remove           Bootstrap danger red

Orange should be used mainly for:

-   Main buttons
-   Important prices/discounts where appropriate
-   Active navigation accents
-   Cart actions
-   Selected states
-   Small highlights

Do not make entire sections orange.

## Typography

Use a clean system/font stack such as:

``` css
font-family: Arial, Helvetica, sans-serif;
```

Suggested hierarchy:

-   Hero heading: `48–60px` desktop
-   Page title: `32–40px`
-   Section heading: `24–32px`
-   Card/product title: `16–18px`
-   Body: `14–16px`
-   Small/meta text: `12–14px`

Use bold headings and normal/medium body text.

## Corners

Keep corners modern but restrained:

``` css
border-radius: 10px;
```

Use approximately:

-   Cards: 10--14px
-   Forms: 6--10px
-   Buttons: 6--8px
-   Product images: 8--12px

## Shadows

Use subtle shadows only:

``` css
box-shadow: 0 4px 20px rgba(0,0,0,0.06);
```

Cards should primarily be separated using whitespace and light borders.

------------------------------------------------------------------------

# 4. Global Layout

Use Bootstrap's standard responsive container:

``` html
<div class="container">
```

Recommended maximum content width should naturally follow Bootstrap's
container breakpoints.

Use:

-   `container`
-   `row`
-   `col-*`
-   `g-3`, `g-4`
-   `py-4`, `py-5`
-   `mb-*`, `mt-*`
-   flex utilities

Maintain generous vertical spacing between major sections.

------------------------------------------------------------------------

# 5. Navbar

Create one consistent navbar for all shopping pages.

## Desktop Layout

Navbar background:

-   Dark navy/black (`#111827`)
-   White text

Structure:

**Left** - Circular orange logo/icon - Brand name: **ShopEase**

**Center** - Home - Shop - Categories - Deals - About

**Right** - Search field - Cart icon - User/account icon

Example visual hierarchy:

``` text
[Logo ShopEase]   Home  Shop  Categories  Deals  About     [Search products...]  [Cart] [User]
```

Use Bootstrap:

-   `navbar`
-   `navbar-expand-lg`
-   `container`
-   `navbar-brand`
-   `navbar-nav`
-   Bootstrap form controls

Since JavaScript is forbidden, do not rely on Bootstrap's JS-powered
mobile collapse. On smaller screens, create a CSS-only responsive
arrangement, such as wrapping or hiding secondary navigation links using
Bootstrap display utilities/custom media queries.

Navbar should remain clean and approximately 64--72px tall on desktop.

------------------------------------------------------------------------

# 6. Homepage

The homepage should contain:

1.  Navbar
2.  Hero
3.  Shopping benefits/features
4.  Featured Products

------------------------------------------------------------------------

# 7. Hero Section

Create a large visual hero immediately below the navbar.

## Layout

Desktop:

``` text
------------------------------------------------------
| LARGE TEXT                    | PRODUCT/LIFESTYLE  |
| Upgrade Your                  | IMAGE              |
| Lifestyle                     |                    |
| Description                   |                    |
| [Shop Now →]                  |                    |
------------------------------------------------------
```

Use a warm beige/cream background or a high-quality lifestyle shopping
image.

### Content

Main heading:

**Upgrade Your Lifestyle**

Make **Lifestyle** orange.

Supporting copy:

> Discover top quality products at the best prices. Shop the latest
> trends in tech, fashion and more.

CTA:

**Shop Now →**

The hero should have:

-   Strong visual hierarchy
-   Large lifestyle/product photograph
-   Plenty of whitespace
-   Rounded outer container if desired
-   Approximately 450--550px desktop height

On mobile, stack text above the image.

------------------------------------------------------------------------

# 8. Shopping Benefits Strip

Directly below the hero, create four small benefits:

``` text
[icon] Free Shipping
       On orders over $50

[icon] Secure Payment
       100% secure

[icon] Easy Returns
       Hassle free

[icon] 24/7 Support
       Always here
```

Use Bootstrap grid:

``` text
col-6 col-lg-3
```

Keep this section white with a subtle bottom border.

------------------------------------------------------------------------

# 9. Featured Products

Heading:

**Featured Products**

Place **View All →** on the right.

Desktop should display four product cards in one row.

Suggested examples:

-   Sports Sneakers
-   Smart Watch
-   Travel Backpack
-   Stylish Sunglasses

Each card contains:

1.  Product image
2.  Heart/favorite icon in upper-right
3.  Product name
4.  Price
5.  Five-star rating
6.  Small orange cart button

Card layout:

``` text
+-----------------------+
|                 ♡     |
|     PRODUCT IMAGE     |
|                       |
+-----------------------+
| Product Name          |
| $59.99             🛒 |
| ★★★★★                 |
+-----------------------+
```

Product images should use a consistent aspect ratio.

Recommended CSS:

``` css
.product-image {
    aspect-ratio: 1 / 1;
    object-fit: cover;
}
```

Use subtle card hover effects with CSS only:

-   Slight upward movement
-   Slightly stronger shadow
-   Border-color change

------------------------------------------------------------------------

# 10. Product Listing Page

The product listing page should have two main columns.

## Desktop

``` text
----------------------------------------------------
| FILTER SIDEBAR | ALL PRODUCTS                    |
|                | Sort By [Newest First]          |
| Categories     |                                 |
| Price Range    | [Card] [Card] [Card]            |
| Rating         | [Card] [Card] [Card]            |
| Popular Tags   | [Card] [Card] [Card]            |
----------------------------------------------------
```

Use:

``` text
Sidebar: col-lg-3
Products: col-lg-9
```

## Filter Sidebar

### Categories

Use Bootstrap checkboxes for:

-   Electronics
-   Fashion
-   Home & Living
-   Sports
-   Beauty
-   Accessories

### Price Range

Since there is no JavaScript, show either:

-   Static HTML range controls for visual presentation, or
-   Min/max form fields

Display `$0` and `$500` underneath.

### Rating

Show rows such as:

``` text
★★★★★ & up
★★★★☆ & up
★★★☆☆ & up
★★☆☆☆ & up
```

### Popular Tags

Use Bootstrap badges/pills:

-   New
-   Sale
-   Trending
-   Top Rated

------------------------------------------------------------------------

# 11. Product Grid

At the top:

**All Products**

Below:

`Showing 1–12 of 50 products`

Place a Bootstrap `<select>` on the right:

**Sort by: Newest First**

Suggested options:

-   Newest First
-   Price: Low to High
-   Price: High to Low
-   Top Rated

Because no JavaScript is allowed, this select is visual unless submitted
through an HTML form.

Desktop:

``` text
3 products per row
```

Tablet:

``` text
2 products per row
```

Mobile:

``` text
1 product per row
```

Use Bootstrap responsive columns such as:

``` html
<div class="col-12 col-md-6 col-xl-4">
```

------------------------------------------------------------------------

# 12. Product Details + Reviews Page

Create a dedicated product page.

## Breadcrumb

Example:

``` text
Home / Electronics / Wireless Headphones
```

## Main Product Area

Desktop two-column layout:

``` text
---------------------------------------------------
| PRODUCT IMAGE          | Wireless Headphones    |
|                        | ★★★★★ (124 reviews)    |
|                        | $79.99  $99.99 20% OFF |
|                        | Description             |
| thumbnails             | Color choices          |
|                        | Quantity                |
|                        | [Add to Cart] [Buy Now] |
---------------------------------------------------
```

### Product Gallery

Large square image.

Under it, display four thumbnail cards.

No JavaScript image switching is required. Thumbnails are visual only.

### Product Information

Include:

-   Product title
-   Rating
-   Number of reviews
-   Current price
-   Original crossed-out price
-   Discount badge
-   Short description
-   Color choices
-   Quantity selector UI
-   Add to Cart button
-   Buy Now button

The Add to Cart button should be solid orange.

Buy Now can be white with an orange border.

------------------------------------------------------------------------

# 13. Product Benefits

Under the main product information show:

-   Free Shipping
-   Secure Payment
-   Easy Returns

Use icon + title + small description.

------------------------------------------------------------------------

# 14. Product Information Tabs

Visually represent:

``` text
Description    Specifications    Reviews (124)
```

Because Bootstrap's JavaScript tabs cannot be used, do not implement
interactive tabs.

Instead:

-   Style these as tab-like navigation links, and
-   Display the Reviews section below by default, or
-   Link each item to an HTML anchor on the same page.

------------------------------------------------------------------------

# 15. Reviews Section

Heading:

**Customer Reviews**

Left side:

Large rating:

``` text
4.8
★★★★★
(124 reviews)
```

Right side:

Rating distribution:

``` text
5 ★  ██████████████  70%
4 ★  ████            20%
3 ★  ██               7%
2 ★  █                2%
1 ★                   1%
```

Use Bootstrap progress bars for the distribution.

Include an orange:

**Write a Review**

button.

Below this, individual review cards may optionally contain:

-   Customer name
-   Star rating
-   Date
-   Review text

------------------------------------------------------------------------

# 16. Signup Page

Use a two-column authentication layout.

Desktop:

``` text
----------------------------------------------------
| LIFESTYLE IMAGE       | Create Account           |
|                       | Full Name                 |
| Join ShopEase         | Email Address             |
| Shop Smarter,         | Password                  |
| Live Better           | Confirm Password          |
|                       | [Sign Up]                 |
| Supporting text       | or sign up with           |
|                       | [Google] [Facebook]       |
|                       | Already have account?     |
----------------------------------------------------
```

## Left Panel

Use a lifestyle shopping photograph with a dark overlay.

Text:

**Join ShopEase\
Shop Smarter,\
Live Better**

Supporting text should mention exclusive deals and easier checkout.

## Right Panel

Heading:

**Create Account**

Fields:

-   Full Name
-   Email Address
-   Password
-   Confirm Password

Use:

-   Bootstrap labels
-   `form-control`
-   proper HTML input types
-   `required`

Main button:

**Sign Up**

Full width and orange.

Below:

``` text
or sign up with
[ Google ] [ Facebook ]
```

These are visual buttons only.

Bottom:

**Already have an account? Login**

------------------------------------------------------------------------

# 17. Login Page

Use the same visual language as Signup.

Desktop:

-   Lifestyle/shopping image on the left
-   Login form on the right

Left text:

**Welcome Back!\
Continue Your\
Shopping Journey**

Form:

-   Email Address
-   Password
-   Forgot Password?
-   Login button
-   Google
-   Facebook
-   Don't have an account? Sign Up

Keep Signup and Login visually consistent.

------------------------------------------------------------------------

# 18. Add Product to Cart

No JavaScript is allowed, so the "Add to Cart" behavior does not need
dynamic cart logic.

Represent it through navigation:

``` html
<a href="cart.html" class="btn btn-primary-custom">
    Add to Cart
</a>
```

The button should visually communicate the expected e-commerce action.

If HTML forms are preferred, the button may submit to a static cart
page.

------------------------------------------------------------------------

# 19. Display Cart Page

Heading:

**Your Cart (3 items)**

Place:

**← Continue Shopping**

on the right.

Desktop table structure:

  Product                  Price   Quantity   Total Action
  ---------------------- ------- ---------- ------- --------
  Product image + name     price   selector   total delete
  Product image + name     price   selector   total delete
  Product image + name     price   selector   total delete

Each product should show:

-   Thumbnail
-   Name
-   Variant/color/size
-   Price
-   Quantity UI
-   Line total
-   Remove icon

------------------------------------------------------------------------

# 20. Quantity Controls

Display:

``` text
[ − ] [ 1 ] [ + ]
```

Since JavaScript is prohibited, these are static controls or separate
HTML links/buttons.

Do not pretend they dynamically update values.

------------------------------------------------------------------------

# 21. Cart Order Summary

Place a summary card on the lower/right side.

Example:

``` text
Order Summary

Subtotal       $189.97
Shipping         $0.00
-----------------------
Total          $189.97

[ Proceed to Checkout ]
```

The checkout button should be large, full-width, and orange.

------------------------------------------------------------------------

# 22. Edit Cart Page

Use a layout similar to Display Cart.

Heading:

**Edit Cart**

Table columns:

-   Product
-   Price
-   Quantity
-   Total
-   Action

Provide visual quantity controls and remove buttons.

At the bottom:

**Update Cart**

and:

**Continue Shopping**

Because there is no JavaScript/backend, Update Cart is a visual/static
HTML action.

------------------------------------------------------------------------

# 23. Checkout Page

The checkout page should feel structured and trustworthy.

At the top create a three-step progress indicator:

``` text
1 Shipping -------- 2 Payment -------- 3 Review
```

Highlight **Shipping** in orange.

No JavaScript multi-step functionality is required. If all steps need
implementation, create separate HTML pages or use anchor sections.

------------------------------------------------------------------------

# 24. Checkout Main Layout

Desktop:

``` text
----------------------------------------------------
| SHIPPING INFORMATION       | ORDER SUMMARY        |
|                            |                      |
| Full Name                  | Product  x2  $159.98 |
| Address                    | Product  x1   $59.99 |
| City      Postal Code      | Product  x1   $49.99 |
| Phone Number               |                      |
|                            | Subtotal              |
|                            | Shipping              |
|                            | Total                 |
|                            |                      |
|                            | [Continue to Payment] |
----------------------------------------------------
```

Use approximately:

``` text
Shipping form: col-lg-7
Order summary: col-lg-5
```

------------------------------------------------------------------------

# 25. Shipping Form

Fields:

-   Full Name
-   Address
-   City
-   Postal Code
-   Phone Number

Use proper Bootstrap form styling.

City and Postal Code can share one row on desktop.

Use HTML validation attributes where appropriate:

``` html
required
type="tel"
```

------------------------------------------------------------------------

# 26. Checkout Order Summary

Display compact product rows:

``` text
[image] Wireless Headphones x2   $159.98
[image] Running Shoes      x1    $59.99
[image] Travel Backpack    x1    $49.99
```

Then:

``` text
Subtotal
Shipping
Total
```

Primary CTA:

**Continue to Payment →**

------------------------------------------------------------------------

# 27. Payment Page

If a separate payment page is created, preserve the same checkout
structure.

Highlight:

``` text
2 Payment
```

Possible visual form:

-   Name on Card
-   Card Number
-   Expiry
-   CVV

For this front-end assignment, use placeholder/demo data only. Do not
collect or process real payment information.

CTA:

**Review Order →**

------------------------------------------------------------------------

# 28. Review Order Page

Highlight:

``` text
3 Review
```

Show:

-   Shipping details
-   Product summary
-   Order totals
-   Placeholder payment method
-   Place Order button

CTA:

**Place Order**

Link this to:

``` text
success.html
```

------------------------------------------------------------------------

# 29. Order Success Page

Create a clean centered confirmation screen.

Large success/check icon.

Heading:

**Order Placed Successfully!**

Text:

> Thank you for shopping with ShopEase. Your order has been confirmed.

Show a fictional example order number such as:

**Order #SE123456**

Do not imply that a real order has been processed.

CTA:

**Continue Shopping**

The page should use large amounts of whitespace and minimal
distractions.

------------------------------------------------------------------------

# 30. Product Photography

Use modern high-quality product/lifestyle images.

Suggested product categories:

-   Wireless headphones
-   Smart watch
-   Sneakers
-   Backpack
-   Sunglasses
-   Perfume
-   Home decor
-   Furniture
-   Fashion accessories

Images should:

-   Be sharp
-   Have clean backgrounds
-   Use consistent proportions
-   Avoid visible watermarks
-   Look visually cohesive

Use `object-fit: cover` or `object-fit: contain` depending on the
product.

------------------------------------------------------------------------

# 31. Cards

Product cards should use a consistent component style.

Recommended structure:

``` html
<div class="card product-card h-100">
    <div class="product-image-wrapper">
        <img src="..." class="card-img-top product-image" alt="Product name">
    </div>

    <div class="card-body">
        <h5 class="card-title">Product Name</h5>
        <p class="product-price">$79.99</p>
        <div class="rating">★★★★★</div>
    </div>
</div>
```

Maintain equal-height cards using Bootstrap's `h-100`.

------------------------------------------------------------------------

# 32. Buttons

Create a reusable branded button class.

Example:

``` css
.btn-shop {
    background: #ff5a1f;
    border-color: #ff5a1f;
    color: #fff;
}

.btn-shop:hover {
    background: #e94b12;
    border-color: #e94b12;
    color: #fff;
}
```

Use it consistently for:

-   Shop Now
-   Add to Cart
-   Sign Up
-   Login
-   Proceed to Checkout
-   Continue to Payment
-   Place Order
-   Continue Shopping

Secondary actions should use Bootstrap outline buttons.

------------------------------------------------------------------------

# 33. Icons

Bootstrap Icons may be used for:

-   Cart
-   User
-   Search
-   Heart
-   Trash/delete
-   Shipping
-   Secure payment
-   Returns
-   Support
-   Check mark
-   Stars where appropriate

Keep icon styling consistent.

------------------------------------------------------------------------

# 34. Responsive Design

The entire website must work at:

-   Desktop
-   Laptop
-   Tablet
-   Mobile

## Desktop

Use full multi-column layouts.

## Tablet

-   Product grid: 2 columns
-   Reduce hero heading size
-   Filters may stack above products if space is limited

## Mobile

-   Stack hero content
-   One product per row when appropriate
-   Authentication image panel may move above the form or be hidden
-   Cart tables should be placed inside `.table-responsive`
-   Checkout columns should stack
-   Benefits can use two columns
-   Reduce section padding
-   Keep CTA buttons easy to tap
-   Navigation should use a CSS-only mobile arrangement because
    JavaScript is forbidden

Suggested breakpoints should follow Bootstrap defaults.

------------------------------------------------------------------------

# 35. Accessibility

Use semantic HTML.

Required:

-   `<nav>`
-   `<main>`
-   `<section>`
-   `<footer>`
-   `<form>`
-   `<label>`
-   `<button>` / `<a>`

Every image must have meaningful `alt` text.

Every form field must have an associated `<label>`.

Maintain readable color contrast.

Do not communicate information using color alone.

------------------------------------------------------------------------

# 36. Recommended File Structure

``` text
shopease/
│
├── index.html
├── products.html
├── product-details.html
├── signup.html
├── login.html
├── cart.html
├── edit-cart.html
├── checkout.html
├── payment.html
├── review-order.html
├── success.html
│
├── css/
│   └── style.css
│
└── images/
    ├── hero/
    ├── products/
    └── auth/
```

No JavaScript folder is required.

------------------------------------------------------------------------

# 37. Bootstrap Rules

Use Bootstrap heavily instead of recreating Bootstrap features in CSS.

Prefer:

``` text
container
row
col-*
d-flex
align-items-center
justify-content-between
gap-*
py-*
px-*
my-*
mb-*
card
btn
badge
form-control
form-select
table
table-responsive
progress
breadcrumb
```

Custom CSS should be used for:

-   Brand colors
-   Product image dimensions
-   Hero styling
-   Card hover effects
-   Special visual spacing
-   Authentication image overlays
-   Responsive refinements

------------------------------------------------------------------------

# 38. Restrictions

The implementation must remain a pure front-end assignment.

### Allowed

-   HTML5
-   CSS3
-   Bootstrap 5 CSS
-   Bootstrap Icons
-   Static images
-   HTML forms
-   HTML links
-   CSS hover/focus states
-   CSS media queries

### Not Allowed

-   JavaScript
-   Bootstrap JavaScript bundle
-   jQuery
-   React
-   Angular
-   Vue
-   Tailwind
-   Node.js
-   Dynamic cart logic
-   AJAX/fetch
-   LocalStorage
-   Backend code
-   Database code

Do not include JavaScript even for the navbar.

------------------------------------------------------------------------

# 39. Required Visual Consistency

All pages must feel like one website.

Keep the following consistent:

-   Same navbar
-   Same orange primary color
-   Same dark heading color
-   Same border radius
-   Same form styling
-   Same card styling
-   Same product image treatment
-   Same typography
-   Same spacing system
-   Same button appearance

Avoid creating each page with a different visual theme.

------------------------------------------------------------------------

# 40. Final Quality Target

The finished website should look like a polished modern e-commerce
front-end rather than a basic Bootstrap classroom exercise.

The visual priority should be:

**large product imagery → clear headings → product information →
prices/ratings → strong orange CTAs**

Use Bootstrap to make the implementation clean and responsive, while
custom CSS provides the final visual polish.

The final result should closely reproduce the approved ShopEase mockup
and clearly demonstrate the complete shopping journey:

**Homepage → Products → Product Details/Reviews → Add to Cart →
Display/Edit Cart → Checkout → Order Confirmation**

along with:

**Signup + Login**

All of this must be achieved with **HTML + CSS + Bootstrap only, with
absolutely no JavaScript**.
